extends SceneTree
## Headless engine-side tests: the Rust binding through GDScript, the click
## layers, and every shipped level. Run with
##   godot --headless --path godot --script res://tests/run_tests.gd
## (tools/build.ps1 -Test / tools/build.sh --test). Exit code 1 on failure.

var _fails := 0
var _count := 0


func _init() -> void:
	print("DOWNBEAT engine tests")
	_test_binding_present()
	if ClassDB.class_exists("DbGame"):
		_test_binding_round_trip()
		_test_fill_level()
		_test_street_level()
		_test_damage_through_binding()
		_test_drills_and_restart()
		_test_mods_volley_integrity()
		_test_bot_through_binding()
		_test_levels_compile()
		_test_replay_round_trip()
	_test_click_layers()
	_test_kit()
	print("%d checks, %d failed" % [_count, _fails])
	quit(1 if _fails > 0 else 0)


func _check(name: String, ok: bool, detail: String = "") -> void:
	_count += 1
	if ok:
		print("  ok    " + name)
	else:
		_fails += 1
		print("  FAIL  " + name + ("   " + detail if not detail.is_empty() else ""))


func _test_binding_present() -> void:
	_check("DbGame class registered", ClassDB.class_exists("DbGame"), "run tools/build.ps1 first")


func _test_binding_round_trip() -> void:
	var g = ClassDB.instantiate("DbGame")
	_check("load_warmup", g.load_warmup(128.0, 0.0, 0.0))
	_check("bpm", is_equal_approx(g.bpm(), 128.0))
	_check("target_count", g.target_count() == 70, str(g.target_count()))
	var t: Dictionary = g.target(0)
	_check("target dict keys", t.has("kind") and t.has("hit_time") and t.has("radius") and t.has("yaw"), str(t.keys()))
	_check("first target at beat 8", is_equal_approx(float(t.hit_beat), 8.0))
	var rooms: Array = g.rooms()
	_check("range room", rooms.size() == 1 and str(rooms[0].name) == "range", str(rooms))
	var stand: Vector3 = rooms[0].stand
	var p: Vector3 = g.target_position_at(0, float(t.hit_time))
	var rel := p - (stand + Vector3(0, 1.6, 0))
	_check("target 12 m down the lane from the stand", rel.z < 0.0 and absf(Vector2(rel.x, rel.z).length() - 12.0) < 0.05, str(rel))
	_check("target pos matches target()", (t.pos as Vector3).is_equal_approx(p))
	var r: Dictionary = g.rating()
	_check("rating anchor", absf(float(r.stars) - 3.0) < 0.02, str(r))
	_check("fingerprint", str(g.chart_fingerprint()).length() == 16)


func _test_street_level() -> void:
	var g = ClassDB.instantiate("DbGame")
	_check("load_street", g.load_street(128.0, 0.0, 0.0))
	var rooms: Array = g.rooms()
	_check("three rooms in path order", rooms.size() == 3 and str(rooms[0].name) == "street" and str(rooms[2].name) == "platform", str(rooms.size()))
	var prev_z := 0.0
	var ordered := true
	for r in rooms:
		var o: Vector3 = r.origin
		if o.z >= prev_z:
			ordered = false
		prev_z = o.z
	_check("rooms descend along -Z", ordered)
	var spans: Array = g.spans()
	_check("spans: traversal first, encounters present", spans.size() == 7 and str(spans[0].kind) == "traversal" and str(spans[1].kind) == "encounter", str(spans.size()))
	var t: Dictionary = g.target(0)
	_check("target carries room/enemy/damage/pos", t.has("room") and t.has("enemy") and int(t.damage) > 0 and t.has("pos"), str(t.keys()))
	_check("hp starts at 100", int(g.hp()) == 100)


func _test_fill_level() -> void:
	var g = ClassDB.instantiate("DbGame")
	_check("load_fill", g.load_fill(150.0, 0.0, 0.0))
	var kinds := {}
	for i in g.target_count():
		kinds[g.target(i).kind] = true
	_check("fill has RUSH targets", kinds.has("RUSH"), str(kinds.keys()))
	_check("fill drum_stem default -1", int(g.drum_stem()) == -1)
	_check("fill kit_paths empty", (g.kit_paths() as Dictionary).is_empty())
	_check("fill rates above warmup", float(g.rating().stars) > 3.0, str(g.rating()))


func _test_kit() -> void:
	var kit := Kit.build()
	_check("kit has every voice", kit.size() == 6 and kit.has("RUSH") and kit.has("DEAD"), str(kit.keys()))
	for kind in kit:
		var w: AudioStreamWAV = kit[kind]
		var frames := w.data.size() / 2
		_check("kit %s non-silent" % kind, frames > 1000 and _rms(w.data, 0, mini(frames, 400)) > 0.02, str(frames))


func _test_damage_through_binding() -> void:
	# Nobody shoots: every enemy fires; damage and down events arrive in order.
	var g = ClassDB.instantiate("DbGame")
	g.load_warmup(128.0, 0.0, 0.0)
	g.start(0.0)
	var damages := 0
	var downs := 0
	var last_hp := 100
	var ok := true
	var t := 0.0
	var total: float = g.chart_total_time() + 0.5
	while t < total:
		for e in g.update(1.0 / 60.0, false, 0.0):
			if e.type == "damage":
				damages += 1
				if int(e.hp) >= last_hp and last_hp != 100:
					ok = false
				last_hp = int(e.hp)
			elif e.type == "down":
				downs += 1
				last_hp = 100
		t += 1.0 / 60.0
	var rep: Dictionary = g.report()
	_check("damage events for every non-track enemy", damages + downs == 68, "%d + %d" % [damages, downs])
	_check("downs recorded", downs >= 5 and int(rep.downs) == downs, str(downs))
	_check("hp decreases between downs", ok)


func _test_drills_and_restart() -> void:
	var g = ClassDB.instantiate("DbGame")
	var ds: Array = g.drills()
	_check("drill catalogue", ds.size() >= 6 and ds[0].has("name") and ds[0].has("pass_beats"), str(ds.size()))
	_check("load_drill switch 150 x 1 min", g.load_drill("switch", 150.0, 1.0, 0.0))
	_check("drill duration ~ 1 min", absf(float(g.chart_total_time()) - 60.0) < 30.0, str(g.chart_total_time()))
	_check("rank_for / bpm_band", str(g.rank_for(0.9)) == "PLATINUM" and str(g.bpm_band(150.0)) == "140-159")
	# Nobody shoots a drill: the down restarts it; a restart event arrives and spawns repeat.
	g.set_no_fail(false)
	g.load_drill("gridshot", 128.0, 1.0, 0.0)
	g.start(0.0)
	var restarts := 0
	var spawns := 0
	var t := 0.0
	while t < 40.0 and restarts < 2:
		for e in g.update(1.0 / 60.0, false, 0.0):
			if e.type == "restart":
				restarts += 1
				t = float(e.chart_time)
			elif e.type == "spawn":
				spawns += 1
		t += 1.0 / 60.0
	_check("down restarts the section", restarts == 2 and int(g.restarts()) == 2, str(restarts))
	_check("spawns repeat after restart", spawns > int(g.target_count()) * 0 + 10, str(spawns))
	_check("hp refilled after restart", int(g.hp()) == 100, str(g.hp()))


func _test_mods_volley_integrity() -> void:
	var g = ClassDB.instantiate("DbGame")
	g.set_mods("DTHR")
	g.load_warmup(128.0, 0.0, 0.0)
	_check("mods applied: DT bpm", is_equal_approx(float(g.bpm()), 192.0), str(g.bpm()))
	_check("mods label", str(g.mods()) == "DTHR")
	_check("mod multiplier", absf(float(g.mod_multiplier()) - 1.12 * 1.06) < 1e-6)
	var meta: Dictionary = g.level_meta()
	_check("level_meta", meta.has("song") and meta.has("difficulty"))
	g.set_mods("NM")
	_check("load_street_hard", g.load_street_hard(128.0, 0.0, 0.0) and str(g.level_meta().difficulty) == "Hard")
	# Volley through the binding: kill 16 on the beat, mark, release on the bar.
	g.load_warmup(120.0, 0.0, 0.0)
	g.start(0.0)
	var killed := 0
	var t := 0.0
	var dt := 1.0 / 120.0
	while killed < 16 and t < 30.0:
		g.update(dt, false, 0.0)
		t += dt
		var ct: float = g.chart_time(t)
		for id in g.target_count():
			var info: Dictionary = g.target(id)
			if info.kind != "TRACK" and float(info.hit_time) <= ct and float(info.hit_time) > ct - dt:
				var v: Dictionary = g.fire(float(info.hit_time), id, 0.0)
				if v.type == "hit":
					killed += 1
	_check("volley charged by 16 on-beat kills", bool(g.volley_ready()) and int(g.volley_charge()) == 16, str(g.volley_charge()))
	# Advance until two switch targets are live, mark them, release on the next bar.
	var live: Array = []
	while live.size() < 2 and t < 40.0:
		g.update(dt, false, 0.0)
		t += dt
		live.clear()
		for id in g.target_count():
			var info: Dictionary = g.target(id)
			if info.kind == "SWITCH" and float(info.spawn_time) <= g.chart_time(t) and float(info.hit_time) + 0.05 > g.chart_time(t):
				live.append(id)
	var marks := 0
	for id in live:
		if g.mark(id):
			marks += 1
	_check("marks accepted", marks >= 2, str(marks))
	var bar_time := ceilf(g.chart_time(t) / 2.0) * 2.0
	var v: Dictionary = g.release(bar_time + 0.01)
	_check("volley kills on the bar", str(v.type) == "volley" and (v.kills as Array).size() == marks, str(v))
	_check("charge spent", int(g.volley_charge()) == 0)
	var rep: Dictionary = g.report()
	_check("report has pp/fc/mods", rep.has("pp") and rep.has("fc") and str(rep.mods) == "NM" and float(rep.pp) > 0.0)
	var integ: Dictionary = g.integrity()
	_check("integrity dict", integ.has("flags") and integ.has("suspicion"))
	var pps: Array[float] = [100.0, 100.0]
	var pr: float = g.profile_rating(pps)
	_check("profile_rating weights 0.95", absf(pr - 195.0) < 1e-6, str(pr))


func _test_bot_through_binding() -> void:
	var g = ClassDB.instantiate("DbGame")
	g.load_warmup(140.0, 0.0, 0.0)
	g.start(-1.0)
	var fired := {}
	var ticks := 0
	var spawns := 0
	var spawned: Array[int] = []
	var tracks := {}
	var t := -1.0
	var dt := 1.0 / 240.0
	var total: float = g.chart_total_time() + 0.5
	while t < total:
		var events: Array = g.update(dt, false, 0.0)
		t += dt
		for e in events:
			match e.type:
				"tick":
					ticks += 1
					for id in tracks:
						g.track_sample(id, true)
				"spawn":
					spawns += 1
					spawned.append(int(e.target))
					if g.target(e.target).kind == "TRACK":
						tracks[e.target] = true
				"track_done":
					tracks.erase(e.target)
		for id in spawned:
			if fired.has(id):
				continue
			var info: Dictionary = g.target(id)
			if info.kind != "TRACK" and float(info.hit_time) <= g.chart_time(t):
				fired[id] = true
				var v: Dictionary = g.fire(float(info.hit_time), id, 0.0)
				if v.type != "hit" or v.timing != "PERFECT":
					_check("shot %d perfect" % id, false, str(v))
	var rep: Dictionary = g.report()
	_check("bot: all targets spawned", spawns == 70, str(spawns))
	_check("bot: finished", g.is_finished())
	_check("bot: perfect == hits == 68", int(rep.perfect) == 68 and int(rep.hits) == 68, "%s/%s" % [rep.perfect, rep.hits])
	_check("bot: no expiries, no whiffs", int(rep.expired) == 0 and int(rep.whiffs) == 0, "%s %s" % [rep.expired, rep.whiffs])
	_check("bot: track 100%", is_equal_approx(float(rep.track_ratio), 1.0), str(rep.track_ratio))
	_check("bot: grade S", str(rep.grade) == "S", str(rep.grade))
	_check("bot: history length", (rep.history as Array).size() == 68)
	_check("bot: ticks ~ sixteenths", ticks > 0 and absi(ticks - int((total + 1.0) * 140.0 / 60.0 * 4.0)) <= 2, str(ticks))


func _test_replay_round_trip() -> void:
	var g = ClassDB.instantiate("DbGame")
	g.load_warmup(128.0, 0.0, 0.0)
	g.start(-1.0)
	var t := -1.0
	while t < 12.0:
		g.update(1.0 / 120.0, false, 0.0)
		t += 1.0 / 120.0
		for id in 4:
			var info: Dictionary = g.target(id)
			if float(info.hit_time) <= g.chart_time(t) and float(info.hit_time) > g.chart_time(t) - 1.0 / 120.0:
				g.fire(float(info.hit_time) + 0.02, id, 0.1)
	var json: String = g.replay_json()
	_check("replay json non-empty", json.length() > 100)
	var rep: Dictionary = g.replay_report(json)
	_check("replay report has score", rep.has("score") and int(rep.hits) == 4, str(rep.get("hits")))


func _test_levels_compile() -> void:
	var g = ClassDB.instantiate("DbGame")
	var dir := DirAccess.open("res://levels")
	_check("levels dir", dir != null)
	if dir == null:
		return
	for f in dir.get_files():
		if not f.ends_with(".json"):
			continue
		var info: Dictionary = g.rate_level_json(FileAccess.get_file_as_string("res://levels/" + f))
		_check("level %s compiles (%.2f stars)" % [f, float(info.get("stars", 0.0))], not info.is_empty() and float(info.get("stars", 0.0)) > 0.0)


func _test_click_layers() -> void:
	var layers := ClickTrack.build_layers(120.0, 8)
	_check("three layers", layers.size() == 3)
	var n := layers[0].data.size()
	_check("layers equal length", layers[1].data.size() == n and layers[2].data.size() == n)
	var spb := 0.5
	var sr := ClickTrack.SAMPLE_RATE
	var pulse_on_beat := _rms(layers[0].data, int(1.0 * spb * sr), 400)
	var pulse_off_beat := _rms(layers[0].data, int(1.25 * spb * sr), 400)
	var hats_off_beat := _rms(layers[1].data, int(1.5 * spb * sr), 200)
	var hats_on_beat := _rms(layers[1].data, int(1.0 * spb * sr), 200)
	var accent_bar := _rms(layers[2].data, int(4.0 * spb * sr), 200)
	var accent_beat := _rms(layers[2].data, int(1.0 * spb * sr), 200)
	_check("pulse sits on the beat", pulse_on_beat > 0.1 and pulse_off_beat < 0.001, "%f %f" % [pulse_on_beat, pulse_off_beat])
	_check("hats sit on the off-beat", hats_off_beat > 0.02 and hats_on_beat < 0.001, "%f %f" % [hats_off_beat, hats_on_beat])
	_check("accent only on bar starts", accent_bar > 0.05 and accent_beat < 0.001, "%f %f" % [accent_bar, accent_beat])


func _rms(data: PackedByteArray, frame: int, count: int) -> float:
	var acc := 0.0
	for i in count:
		var v := data.decode_s16((frame + i) * 2) / 32767.0
		acc += v * v
	return sqrt(acc / count)
