extends Node3D
## Level builder: rooms, corridors and doors from the compiled chart. Every
## mesh is a greybox block (ASSETS.register.md [ENV-*]); the layout, the door
## timing and the start pad are real.

const FLOOR := Palette.CONCRETE
const WALL := Palette.STEEL
const BLOCK := Palette.BLOCK
const DOOR := Palette.VIOLET
const NEON_PINK := Palette.MAGENTA
const NEON_CYAN := Palette.CYAN
const WALL_T := 0.6
const DOOR_W := 4.0
const DOOR_H := 3.2

var doors: Array[StaticBody3D] = []
var _door_open_times: Array[float] = []
var _rooms: Array = []
var _spans: Array = []
var _built_for := ""


func _ready() -> void:
	_environment()
	DB.run_started.connect(_on_run_started)


func _on_run_started(_bpm: float) -> void:
	var key := "%s@%s" % [str(DB.game.level_name()), str(DB.game.chart_fingerprint())]
	if key == _built_for:
		for d in doors:
			d.position.y = 0.0
		return
	_built_for = key
	for c in get_children():
		if c.name.begins_with("Built"):
			c.queue_free()
	_build()


## Rooms in path order; corridors join each room's exit (-Z face) to the next
## room's entrance (+Z face). The start pad sits at z = 0 and the first
## corridor leads from it to the first room.
func _build() -> void:
	var root := Node3D.new()
	root.name = "Built"
	add_child(root)
	_rooms = DB.game.rooms()
	_spans = DB.game.spans()
	doors.clear()
	_door_open_times.clear()
	var prev_exit_z := 0.0
	var prev_half_w := 3.0
	_pad(root, Vector3(0, 0, 4), 8.0)
	for i in _rooms.size():
		var r: Dictionary = _rooms[i]
		var o: Vector3 = r.origin
		var sz: Vector3 = r.size
		var entrance_z := o.z + sz.z * 0.5
		var exit_z := o.z - sz.z * 0.5
		_corridor(root, prev_exit_z, entrance_z, minf(prev_half_w, 3.0))
		_room(root, r, i)
		prev_exit_z = exit_z
		prev_half_w = sz.x * 0.5
	_corridor(root, prev_exit_z, prev_exit_z - 12.0, 3.0)
	_box(root, Vector3(0, 3.0, prev_exit_z - 12.3), Vector3(8, 6, WALL_T), WALL)
	# Door schedule: the door out of encounter k opens when the next traversal starts.
	for s in _spans:
		if s.kind == "traversal":
			_door_open_times.append(float(s.start_time))


func _room(root: Node3D, r: Dictionary, index: int) -> void:
	var o: Vector3 = r.origin
	var sz: Vector3 = r.size
	var hw := sz.x * 0.5
	var hd := sz.z * 0.5
	_box(root, o + Vector3(0, -0.5, 0), Vector3(sz.x, 1, sz.z), FLOOR)
	_box(root, o + Vector3(0, sz.y + 0.5, 0), Vector3(sz.x, 1, sz.z), WALL)
	_box(root, o + Vector3(-hw - WALL_T * 0.5, sz.y * 0.5, 0), Vector3(WALL_T, sz.y, sz.z), WALL)
	_box(root, o + Vector3(hw + WALL_T * 0.5, sz.y * 0.5, 0), Vector3(WALL_T, sz.y, sz.z), WALL)
	# Entrance (+Z) and exit (-Z) faces with a door gap in the middle.
	for face in [1.0, -1.0]:
		var z := o.z + face * (hd + WALL_T * 0.5)
		var side_w := (sz.x - DOOR_W) * 0.5
		_box(root, Vector3(o.x - DOOR_W * 0.5 - side_w * 0.5, sz.y * 0.5, z), Vector3(side_w, sz.y, WALL_T), WALL)
		_box(root, Vector3(o.x + DOOR_W * 0.5 + side_w * 0.5, sz.y * 0.5, z), Vector3(side_w, sz.y, WALL_T), WALL)
		_box(root, Vector3(o.x, DOOR_H + (sz.y - DOOR_H) * 0.5, z), Vector3(DOOR_W, sz.y - DOOR_H, WALL_T), WALL)
		if face < 0.0:
			var door := _box(root, Vector3(o.x, DOOR_H * 0.5, z), Vector3(DOOR_W, DOOR_H, WALL_T * 0.6), DOOR)
			door.name = "Door%d" % index
			doors.append(door)
	for b in r.blocks:
		_box(root, b.pos, b.size, BLOCK)
	var stand: Vector3 = r.stand
	_strip(root, stand + Vector3(0, 0.02, 0), Vector3(1.4, 0.04, 1.4), NEON_CYAN)
	_strip(root, Vector3(o.x, 0.02, o.z - hd + 0.4), Vector3(sz.x - 2.0, 0.04, 0.3), NEON_PINK)


func _corridor(root: Node3D, from_z: float, to_z: float, half_w: float) -> void:
	var length := from_z - to_z
	if length <= 0.0:
		return
	var mid := (from_z + to_z) * 0.5
	var w := half_w * 2.0
	_box(root, Vector3(0, -0.5, mid), Vector3(w, 1, length), FLOOR)
	_box(root, Vector3(-half_w - WALL_T * 0.5, 2.5, mid), Vector3(WALL_T, 5.0, length), WALL)
	_box(root, Vector3(half_w + WALL_T * 0.5, 2.5, mid), Vector3(WALL_T, 5.0, length), WALL)
	_box(root, Vector3(0, 5.5, mid), Vector3(w, 1, length), WALL)
	var n := int(length / 6.0)
	for i in n:
		var z := from_z - 3.0 - i * 6.0
		_strip(root, Vector3(-half_w + 0.2, 1.2, z), Vector3(0.1, 0.1, 1.6), NEON_CYAN)
		_strip(root, Vector3(half_w - 0.2, 1.2, z), Vector3(0.1, 0.1, 1.6), NEON_CYAN)


func _pad(root: Node3D, at: Vector3, size: float) -> void:
	_box(root, at + Vector3(0, -0.5, 0), Vector3(size, 1, size), FLOOR)
	_box(root, at + Vector3(0, 2.5, size * 0.5 + WALL_T * 0.5), Vector3(size, 5, WALL_T), WALL)
	_box(root, at + Vector3(-size * 0.5 - WALL_T * 0.5, 2.5, 0), Vector3(WALL_T, 5, size), WALL)
	_box(root, at + Vector3(size * 0.5 + WALL_T * 0.5, 2.5, 0), Vector3(WALL_T, 5, size), WALL)
	_strip(root, Vector3(0, 0.02, 0), Vector3(1.2, 0.04, 1.2), NEON_CYAN)


func _process(delta: float) -> void:
	if not DB.running or DB.game == null:
		return
	var ct := DB.chart_time_now()
	for i in doors.size():
		if i < _door_open_times.size() and ct >= _door_open_times[i] and doors[i].position.y < DOOR_H * 0.99:
			doors[i].position.y = minf(doors[i].position.y + delta * DOOR_H * 2.0, DOOR_H)


func _environment() -> void:
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Palette.INK
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.35, 0.30, 0.50)
	env.ambient_light_energy = 0.6
	env.glow_enabled = true
	env.glow_intensity = 0.6
	env.glow_bloom = 0.15
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48, 32, 0)
	sun.light_energy = 1.4
	sun.light_color = Color(1.0, 0.92, 0.85)
	sun.shadow_enabled = true
	add_child(sun)


func _box(root: Node3D, at: Vector3, size: Vector3, color: Color) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.position = at
	var mesh := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mesh.mesh = bm
	mesh.material_override = Cel.material(color)
	body.add_child(mesh)
	var col := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	col.shape = shape
	body.add_child(col)
	root.add_child(body)
	return body


func _strip(root: Node3D, at: Vector3, size: Vector3, color: Color) -> void:
	var mesh := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mesh.mesh = bm
	mesh.position = at
	mesh.material_override = Cel.material(color, 3.0, color, false)
	root.add_child(mesh)
