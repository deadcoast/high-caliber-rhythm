# DOWNBEAT

Cel-shaded cyberpunk FPS rhythm game / aim trainer. Greybox build: the backend is real, every visual is a
placeholder tracked in `ASSETS.register.md`.

```
core/     Rust game model (clock, BPM-space charts, judge, scoring, replays, analyser, simulator) + Godot bindings + wasm ABI
godot/    Godot 4.7 project: rooms, player, enemies, HUD, results, Range, Any Song, replays, shaders, levels
web/      chart editor: Svelte 5 over the wasm core (song analysis, path, patterns, timeline, rating, bot)
tools/    build.ps1 / build.sh: one command, builds the extension and stages it; -Web builds the editor
```

## Run

Requires Rust (stable) and Godot 4.7.x. No Unity, no Unreal.

```powershell
.\tools\build.ps1 -Test -Smoke       # Windows: build core, stage dll, engine tests, headless autoplay run
.\tools\build.ps1 -Run -Bpm 128      # build, then launch the warmup
```
```bash
tools/build.sh --test --smoke        # Linux/macOS
tools/build.sh --run --bpm=174
```

With no flags the game opens on the menu: level select (builtins at any BPM, every shipped level, every
Any Song level; stars and best under the chosen mods), settings (`S`: sensitivity, DPI, offset with `C` to
calibrate, FOV, frame cap, post-FX, volume, cue tuning), `Tab` the Range, `O` the Any Song picker. `Esc`
pauses a run (resume, restart, level select, settings, Range, quit). Run flags after `--` start a run
directly: `--bpm=N`, `--range=<drill> --minutes=M`, `--warmup` / `--fill`, `--level=res://levels/x.json`,
`--song=<file>` (Any Song, no confirm), `--watch=user://replays/x.json` (watch a run), `--autoplay` (the bot
plays), `--smoke` (print the report and quit), `--replay=user://replays/x.json` (re-score a saved run),
`--list-levels` (every level with rating and best).

`python3 tools/gdcheck.py` checks every GDScript member, constant and call arity against Godot's
`extension_api.json` without launching the engine (uses `godot --dump-extension-api` output or the
copy in the gdext dependency cache).

In game: mouse look (34 cm/360 @ 800 DPI, in settings), LMB tap = shot / hold = beam, RMB hold = mark for
the Downbeat, release on the bar; WASD, Shift sprint, Ctrl slide (while sprinting), Space jump (mantles
low ledges), `Q` beat dash, `Tab` Range (1–5 toggle DT HT HR HD NF), `O` Any Song, `R` restart, `C` calibrate,
`Esc` mouse. Flags: `--hard` (Street Hard), `--mods=DTHR`.

After a run the results screen shows the grade, score, pp, judgement histogram, timing histogram and
scatter, per-enemy table and this chart's leaderboard; `Enter` watches the replay (the camera follows the
recorded run; `R` then plays the level yourself), `R` retries, `Tab` opens the Range, `Esc` closes.

Any Song (`O`): pick a wav/flac/ogg/mp3/m4a, the core measures tempo and beat 0 on a worker thread, the
confirm screen plays the song with a click on the grid (Left/Right nudge beat 0 by 10 ms, Shift 1 ms,
Up/Down halve/double the BPM, `[`/`]` ±0.5, Space skips 8 bars), `Enter` builds the energy-mapped chart into
`user://songs/` and plays it. Every song level restarts, scores and replays like a shipped level.

## Verify the model without the engine

```
cd core
cargo test                                  # 51 tests
cargo run --bin dbsim -- --sweep            # bot plays the warmup at 90 / 128 / 174 BPM
cargo run --bin dbsim -- --bot perfect --bpm 160
cargo run --bin dbsim -- --street --bpm 140 # the act-one level, human bot
cargo run --bin dbsim -- --level-json 140 --street > ../godot/levels/street_140.json
cargo run --release --bin dbmap -- song.wav --set flick --audio res://audio/song.wav --out ../godot/levels
cargo run --release --bin dbmap -- song.wav --auto        # patterns chosen bar by bar from the song's energy
cargo run --release --bin dbmap -- --synth 140 0.42 30    # analyser self-test on a synthetic track
cargo run --release --bin dbmap -- --synth 128 0.2 60 6 --auto   # ... with a 6-bar quiet intro
```

Scores: top-10 leaderboard per chart fingerprint and mod set in `user://scores.json` (pp, grade, FC/PFC,
replay path, integrity flags); profile rating = osu-weighted best pp per chart.
Stats: every run in `user://stats.json`; the Range shows per-drill means in the current BPM band, the band rank
(Iron to Diamond from the last 20 runs) and today's routine (the five weakest cells). Cue tuning lives in
`user://downbeat.cfg` under `[cue]`: `ring_start` (ring size at spawn, × radius), `pop_ms`, `telegraph`.

## Chart editor

`tools/build.ps1 -Web` (or `cd web && npm install && npm run core && npm run build`) builds the editor into
`web/dist`; `npm run dev` serves it live. Song in, grid by ear, path and patterns by hand or from the song's
energy, timeline, rating and bot run on every edit, level JSON out. See `web/README.md`.

## Night Market

The first produced track: an original 132 BPM piece in A minor, 88 bars, written as a section plan in
`core/src/song.rs` and rendered by the core to four stems (`base` kick/bass/pad, `perc` hats/clap, `keys`
stabs, `lead` melody/snare) that open at combo 0/10/25/50. The build renders them into `godot/audio/`
when missing (`dbsong --out godot/audio`). `godot/levels/night_market_132.json` is the hand chart in the
editor's format: a traversal through the intro, the street for build and verse, a door on the chorus
downbeat into the atrium (two inline patterns follow the melody's rhythm), the break walked to the
platform, the drop with striders under the hats. The analyser reads the mix back at 132.00 BPM; the human
bot clears it (tested). SCAFFOLD AUDIO: a commissioned track replaces the stems, the pipeline stays.

## Songs

`dbmap song.wav` prints tempo, beat 0 and an onset grid, and writes a level that fills the song's bars.
Put the audio under `godot/audio/` and pass `--audio res://audio/<file>` (or list `stems` in the JSON:
they play sample-locked and open by combo tier). Then `.\tools\build.ps1 -Run` with
`--level=res://levels/<name>.json`. Settings persist in `user://downbeat.cfg`; replays in `user://replays/`.

## Levels

`godot/levels/*.json`. `bpm`, `lead_in` (beats), `rooms` (name, size, stand, yaw_deg, blocks; origin
optional, laid out by the compiler), `segments` (`traversal {bars}` / `encounter {room, sections}`), or the
shorthand `sections` for a single Range encounter; optional inline `patterns`; `audio` (empty = click),
`stems` (combo-tiered), `song_offset_s`, `kit` (kind label → hit-sound path; empty = synthesised).
Builtin patterns: `flick_lr`, `flick_quad`, `flick_8ths`, `switch_pair`, `micro_walk`, `micro_zigzag`,
`track_sweep`, `track_arc`, `rush_fill`, `rest`. Builtin levels: `street` (act one, level one), `warmup`
(Range reference, rating anchor), `fill` (Range, every kind).

The plan: `PLAN.md`. Design mechanisms: `DESIGN.md`. Art schedule: `ASSETS.register.md`.
