class_name ClickTrack
extends RefCounted
## Procedural count-in / metronome stream at any BPM, built in memory so the
## conductor has a real audio clock to lock to before a song exists.
## SCAFFOLD AUDIO: replaced by the licensed/produced track stems. See ASSETS.register.md [AUD-01].

const SAMPLE_RATE := 44100


var _data := PackedByteArray()


static func build(bpm: float, beats: int, beats_per_bar: int = 4) -> AudioStreamWAV:
	var track := ClickTrack.new()
	return track._build(bpm, beats, beats_per_bar)


func _build(bpm: float, beats: int, beats_per_bar: int) -> AudioStreamWAV:
	var spb := 60.0 / bpm
	var total_frames := int(ceil(beats * spb * SAMPLE_RATE)) + SAMPLE_RATE
	_data.resize(total_frames * 2)
	_data.fill(0)
	var down := _tone(1320.0, 0.055, 0.9)
	var quarter := _tone(880.0, 0.040, 0.6)
	var eighth := _noise(0.012, 0.18)
	for b in beats:
		var frame := int(round(b * spb * SAMPLE_RATE))
		_mix(frame, down if b % beats_per_bar == 0 else quarter)
		_mix(frame + int(round(spb * 0.5 * SAMPLE_RATE)), eighth)
	var stream := AudioStreamWAV.new()
	stream.format = AudioStreamWAV.FORMAT_16_BITS
	stream.mix_rate = SAMPLE_RATE
	stream.stereo = false
	stream.data = _data
	return stream


static func _tone(freq: float, seconds: float, gain: float) -> PackedFloat32Array:
	var n := int(seconds * SAMPLE_RATE)
	var out := PackedFloat32Array()
	out.resize(n)
	for i in n:
		var t := float(i) / SAMPLE_RATE
		var env := 1.0 - float(i) / n
		env = env * env
		out[i] = sin(TAU * freq * t) * env * gain
	return out


static func _noise(seconds: float, gain: float) -> PackedFloat32Array:
	var n := int(seconds * SAMPLE_RATE)
	var out := PackedFloat32Array()
	out.resize(n)
	var rng := RandomNumberGenerator.new()
	rng.seed = 7
	for i in n:
		var env := 1.0 - float(i) / n
		out[i] = rng.randf_range(-1.0, 1.0) * env * gain
	return out


func _mix(frame: int, sample: PackedFloat32Array) -> void:
	var limit := _data.size() / 2
	for i in sample.size():
		var f := frame + i
		if f < 0 or f >= limit:
			continue
		var cur := _data.decode_s16(f * 2) / 32767.0
		var v := clampf(cur + sample[i], -1.0, 1.0)
		_data.encode_s16(f * 2, int(v * 32767.0))
