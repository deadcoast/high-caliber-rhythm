extends Node3D
## Entry point. Starts the warmup run at the chosen BPM.
##   godot --path godot -- --bpm=174        run the warmup at 174
##   godot --path godot -- --level=res://levels/warmup_128.json
##   godot --headless --path godot -- --smoke    run to the end, print the report JSON, quit

@export var bpm := 128.0


func _ready() -> void:
	var args := OS.get_cmdline_user_args()
	var level := ""
	for a in args:
		if a.begins_with("--bpm="):
			bpm = float(a.trim_prefix("--bpm="))
		elif a.begins_with("--level="):
			level = a.trim_prefix("--level=")
	if "--smoke" in args:
		DB.run_finished.connect(func(r: Dictionary) -> void:
			print("DOWNBEAT SMOKE " + JSON.stringify(r))
			get_tree().quit())
	if level.is_empty():
		DB.start_warmup(bpm)
	else:
		DB.start_level(level)
