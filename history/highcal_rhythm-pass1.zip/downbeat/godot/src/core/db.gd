extends Node
## DB: the game driver (autoload).
## Owns the Rust game model (DbGame from downbeat_core), the audio clock and the
## event bus. Everything in the scene listens to this node; nothing else touches
## the model.

signal run_started(bpm: float)
signal run_finished(report: Dictionary)
signal tick(index: int, beat: int, sub: int)
signal beat(index: int, in_bar: int)
signal bar(index: int)
signal target_spawned(id: int, info: Dictionary)
signal target_hit(id: int, verdict: Dictionary)
signal whiff(verdict: Dictionary)
signal target_expired(id: int)
signal track_done(id: int, verdict: Dictionary)
signal calibrated(input_offset_ms: float)

const PREROLL_S := 2.0

var game = null
var player: AudioStreamPlayer
var running := false
var level_path := ""
var bpm := 128.0

var _frame_usec: int = 0
var calibrating := false
var _cal_samples: Array[float] = []
var _stream_started := false
var _song_offset_s := 0.0
var _input_offset_ms := 0.0


func _ready() -> void:
	_setup_input_map()
	player = AudioStreamPlayer.new()
	player.name = "Music"
	player.bus = "Master"
	add_child(player)
	if not ClassDB.class_exists("DbGame"):
		push_error("downbeat_core GDExtension not loaded. Run tools/build.ps1 (Windows) or tools/build.sh, then restart.")
		return
	game = ClassDB.instantiate("DbGame")


func _setup_input_map() -> void:
	var defs := {
		"fire": [_mouse(MOUSE_BUTTON_LEFT)],
		"move_forward": [_key(KEY_W)],
		"move_back": [_key(KEY_S)],
		"move_left": [_key(KEY_A)],
		"move_right": [_key(KEY_D)],
		"jump": [_key(KEY_SPACE)],
		"restart": [_key(KEY_R)],
		"release_mouse": [_key(KEY_ESCAPE)],
		"calibrate": [_key(KEY_C)],
	}
	for action in defs:
		if not InputMap.has_action(action):
			InputMap.add_action(action)
			for ev in defs[action]:
				InputMap.action_add_event(action, ev)


func _mouse(button: int) -> InputEventMouseButton:
	var e := InputEventMouseButton.new()
	e.button_index = button
	return e


func _key(code: int) -> InputEventKey:
	var e := InputEventKey.new()
	e.physical_keycode = code
	return e


## Load the builtin warmup chart at a BPM, backed by the procedural click track.
func start_warmup(at_bpm: float) -> void:
	if game == null:
		return
	bpm = at_bpm
	_song_offset_s = 0.0
	player.stream = ClickTrack.build(bpm, 100)
	game.load_warmup(bpm, _song_offset_s, _input_offset_ms)
	_begin()


## Load a level JSON. Fields the model ignores but this driver reads:
##   "audio": "res://audio/song.ogg", "song_offset_s": seconds of beat 0 in the file.
func start_level(path: String) -> void:
	if game == null:
		return
	var text := FileAccess.get_file_as_string(path)
	if text.is_empty():
		push_error("level not found: " + path)
		return
	var parsed = JSON.parse_string(text)
	if typeof(parsed) != TYPE_DICTIONARY:
		push_error("level json invalid: " + path)
		return
	level_path = path
	bpm = float(parsed.get("bpm", 128.0))
	_song_offset_s = float(parsed.get("song_offset_s", 0.0))
	var audio_path: String = str(parsed.get("audio", ""))
	if audio_path.is_empty():
		player.stream = ClickTrack.build(bpm, int(parsed.get("click_beats", 128)))
	else:
		player.stream = load(audio_path)
	if not game.load_level_json(text, _song_offset_s, _input_offset_ms):
		return
	_begin()


## Calibration run: 8 bars of click, no targets. Every click's distance to the
## nearest beat is collected; the median becomes the input offset. Measures the
## whole pipeline on the player's machine: mouse polling, frame, audio output.
func start_calibration() -> void:
	if game == null:
		return
	var json := JSON.stringify({
		"name": "calibrate", "bpm": bpm, "lead_in": 4.0,
		"sections": [{"pattern": "rest", "repeats": 8}],
	})
	player.stream = ClickTrack.build(bpm, 48)
	_song_offset_s = 0.0
	if not game.load_level_json(json, _song_offset_s, 0.0):
		return
	calibrating = true
	_cal_samples.clear()
	_begin()


func _finish_calibration() -> void:
	calibrating = false
	_cal_samples.sort()
	var n := _cal_samples.size()
	var median := 0.0
	if n > 0:
		median = _cal_samples[n / 2] if n % 2 == 1 else (_cal_samples[n / 2 - 1] + _cal_samples[n / 2]) * 0.5
	set_input_offset_ms(-median)
	calibrated.emit(_input_offset_ms)
	restart()


func _begin() -> void:
	player.stop()
	_stream_started = false
	running = true
	_frame_usec = Time.get_ticks_usec()
	game.start(-PREROLL_S)
	run_started.emit(bpm)


func restart() -> void:
	calibrating = false
	if level_path.is_empty():
		start_warmup(bpm)
	else:
		start_level(level_path)


func set_input_offset_ms(ms: float) -> void:
	_input_offset_ms = ms
	if game != null:
		game.set_input_offset_ms(ms)


func input_offset_ms() -> float:
	return _input_offset_ms


## Stream position corrected for output latency, the way the conductor wants it.
func audio_time() -> float:
	return player.get_playback_position() + AudioServer.get_time_since_last_mix() - AudioServer.get_output_latency()


## Song time at this instant: the model's time at the last update plus the
## wall clock since. Used to timestamp clicks between frames.
func input_song_time() -> float:
	if game == null:
		return 0.0
	return game.song_time() + float(Time.get_ticks_usec() - _frame_usec) / 1_000_000.0


func chart_time_now() -> float:
	return game.chart_time(game.song_time()) if game != null else 0.0


func beat_phase() -> float:
	return game.beat_phase() if game != null else 0.0


func _process(delta: float) -> void:
	if not running or game == null:
		return
	var has_audio := player.playing
	var events: Array = game.update(delta, has_audio, audio_time() if has_audio else 0.0)
	_frame_usec = Time.get_ticks_usec()
	if not _stream_started and game.song_time() >= 0.0:
		player.play(maxf(0.0, game.song_time()))
		_stream_started = true
	for e in events:
		_route(e)
	if game.is_finished():
		running = false
		player.stop()
		if calibrating:
			_finish_calibration()
		else:
			run_finished.emit(game.report())


func _route(e: Dictionary) -> void:
	match e.get("type", ""):
		"tick":
			tick.emit(e.index, e.beat, e.sub)
		"beat":
			beat.emit(e.index, e.in_bar)
		"bar":
			bar.emit(e.index)
		"spawn":
			target_spawned.emit(e.target, game.target(e.target))
		"hit":
			target_hit.emit(e.target, e)
		"whiff":
			whiff.emit(e)
			if calibrating:
				_cal_samples.append(float(e.delta_ms))
				if _cal_samples.size() >= 16:
					_finish_calibration()
		"expired":
			target_expired.emit(e.target)
		"track_done":
			track_done.emit(e.target, e)
		"ignored":
			pass


## A click: raw song time measured at the input event, the target id the ray
## hit (-1 for none) and the ray's distance from the target centre in metres.
func fire(raw_song_time: float, target_id: int, offset_m: float) -> Dictionary:
	if game == null or not running:
		return {}
	var v: Dictionary = game.fire(raw_song_time, target_id, offset_m)
	_route(v)
	return v


func track_sample(target_id: int, on_target: bool) -> void:
	if game != null and running:
		game.track_sample(target_id, on_target)
