# One command: build the Rust core as a GDExtension and stage it for the Godot project.
#   .\tools\build.ps1            release build
#   .\tools\build.ps1 -Debug     debug build
#   .\tools\build.ps1 -Run       build, then launch the warmup in Godot (needs `godot` on PATH or $env:GODOT)
param([switch]$Debug, [switch]$Run, [double]$Bpm = 128)
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$profile = if ($Debug) { "debug" } else { "release" }
$flags = @("build", "--features", "gdext")
if (-not $Debug) { $flags += "--release" }
Write-Host "[downbeat] cargo $($flags -join ' ')"
Push-Location "$root\core"
try { cargo @flags } finally { Pop-Location }
New-Item -ItemType Directory -Force "$root\godot\bin" | Out-Null
Copy-Item "$root\core\target\$profile\downbeat_core.dll" "$root\godot\bin\downbeat_core.dll" -Force
Write-Host "[downbeat] staged godot\bin\downbeat_core.dll ($profile)"
if ($Run) {
    $godot = if ($env:GODOT) { $env:GODOT } else { "godot" }
    & $godot --path "$root\godot" -- "--bpm=$Bpm"
}
