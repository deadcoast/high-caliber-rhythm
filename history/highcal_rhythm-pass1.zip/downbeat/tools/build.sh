#!/usr/bin/env bash
# One command: build the Rust core as a GDExtension and stage it for the Godot project.
#   tools/build.sh            release build
#   tools/build.sh --debug    debug build
#   tools/build.sh --run      build, then launch the warmup (needs `godot` on PATH or $GODOT)
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
profile=release; flags=(build --features gdext --release); run=0; bpm=128
for a in "$@"; do case "$a" in
  --debug) profile=debug; flags=(build --features gdext);;
  --run) run=1;;
  --bpm=*) bpm="${a#--bpm=}";;
esac; done
echo "[downbeat] cargo ${flags[*]}"
(cd "$root/core" && cargo "${flags[@]}")
mkdir -p "$root/godot/bin"
case "$(uname -s)" in
  Darwin) cp "$root/core/target/$profile/libdownbeat_core.dylib" "$root/godot/bin/";;
  *) cp "$root/core/target/$profile/libdownbeat_core.so" "$root/godot/bin/";;
esac
echo "[downbeat] staged godot/bin ($profile)"
if [ "$run" = 1 ]; then "${GODOT:-godot}" --path "$root/godot" -- "--bpm=$bpm"; fi
