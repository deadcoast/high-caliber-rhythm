# DOWNBEAT

Cel-shaded cyberpunk FPS rhythm game / aim trainer. Greybox build: the backend is real, every visual is a
placeholder tracked in `ASSETS.register.md`.

```
core/     Rust game model (clock, BPM-space charts, judge, scoring, simulator) + Godot bindings
godot/    Godot 4.7 project: arena, player, targets, HUD, shaders, levels
tools/    build.ps1 / build.sh: one command, builds the extension and stages it
```

## Run

Requires Rust (stable) and Godot 4.7.x. No Unity, no Unreal.

```powershell
.\tools\build.ps1 -Run -Bpm 128      # Windows: build core, stage dll, launch warmup
```
```bash
tools/build.sh --run --bpm=174       # Linux/macOS
```

In game: mouse look (34 cm/360 @ 800 DPI, edit in `player.gd`), LMB fire / hold to track, WASD, Space,
`R` restart, `C` calibrate (tap 16 beats, offset is set from the median), `Esc` release mouse.

## Verify the model without the engine

```
cd core
cargo test                       # 21 tests
cargo run --bin dbsim -- --sweep # bot plays the warmup at 90 / 128 / 174 BPM
cargo run --bin dbsim -- --bot perfect --bpm 160
cargo run --bin dbsim -- --level-json 140 > ../godot/levels/warmup_140.json
```

## Levels

`godot/levels/*.json`. `bpm`, `lead_in` (beats), `sections` of builtin pattern names × repeats, optional
inline `patterns`. Driver-only fields: `audio` (stream path; absent = procedural click), `song_offset_s`.
Builtin patterns: `flick_lr`, `flick_quad`, `flick_8ths`, `switch_pair`, `micro_walk`, `micro_zigzag`,
`track_sweep`, `track_arc`, `rest`.
