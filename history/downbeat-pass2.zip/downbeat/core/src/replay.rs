//! Replays. The model is deterministic, so a run is fully described by its
//! level, clock settings and the ordered inputs. Replaying produces the same
//! report, which is what a leaderboard validates and what a ghost or spectator
//! view plays back.
//!
//! Every input carries `at`: the chart time the judge had been advanced to
//! when the input was applied live. Replay advances to the same `at` before
//! applying it, so expiries, spawns and tracking state are identical whatever
//! the live frame timing was.

use crate::chart::Level;
use crate::clock::ClockConfig;
use crate::judge::{Hit, Windows};
use crate::score::{Report, Scoring};
use crate::Game;
use serde::{Deserialize, Serialize};

#[derive(Clone, Copy, Debug, Serialize, Deserialize, PartialEq)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum Input {
    /// A click: raw stream time as the engine measured it (before calibration),
    /// the target the ray hit (-1 = none) and ray-to-centre distance.
    Shot { at: f64, raw_time: f64, target: i64, offset_m: f32 },
    /// A tracking sample.
    Track { at: f64, target: u32, on: bool },
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct Replay {
    pub level: Level,
    pub clock: ClockConfig,
    pub windows: Windows,
    pub scoring: Scoring,
    pub inputs: Vec<Input>,
}

impl Replay {
    pub fn to_json(&self) -> String {
        serde_json::to_string(self).expect("replay serialises")
    }

    pub fn from_json(s: &str) -> Result<Replay, serde_json::Error> {
        serde_json::from_str(s)
    }

    /// Replay to a report.
    pub fn play(&self) -> Result<Report, crate::chart::CompileError> {
        let mut game = Game::from_level(&self.level, self.clock, self.windows, self.scoring)?;
        game.start(-1.0);
        for input in &self.inputs {
            match *input {
                Input::Shot { at, raw_time, target, offset_m } => {
                    game.seek_chart_time(at);
                    let hit = if target >= 0 { Some(Hit { target: target as u32, offset_m }) } else { None };
                    game.fire(raw_time, hit);
                }
                Input::Track { at, target, on } => {
                    game.seek_chart_time(at);
                    game.track_sample(target, on);
                }
            }
        }
        game.seek_chart_time(game.chart().total_time + 1.0);
        Ok(game.report())
    }
}
